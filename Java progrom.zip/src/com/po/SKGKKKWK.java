package com.po;

public class SKGKKKWK {
    private String cstid;
    private String skyym;
    private String skg;
    private String bankcd;
    private String bchcd;
    private String ykn;
    private String actno;
    private String actnae;
    private String syoflg;
    private String bktskz;
    private String insertdte;
    private String inserttd;
    private String updateid;
    private String updatedte;
    private String deleteflg;
    private String deteledte;

    @Override
    public String toString() {
        return "SKGKKKWK{" +
                "cstid='" + cstid + '\'' +
                ", skyym='" + skyym + '\'' +
                ", skg='" + skg + '\'' +
                ", bankcd='" + bankcd + '\'' +
                ", bchcd='" + bchcd + '\'' +
                ", ykn='" + ykn + '\'' +
                ", actno='" + actno + '\'' +
                ", actnae='" + actnae + '\'' +
                ", syoflg='" + syoflg + '\'' +
                ", bktskz='" + bktskz + '\'' +
                ", insertdte='" + insertdte + '\'' +
                ", inserttd='" + inserttd + '\'' +
                ", updateid='" + updateid + '\'' +
                ", updatedte='" + updatedte + '\'' +
                ", deleteflg='" + deleteflg + '\'' +
                ", deteledte='" + deteledte + '\'' +
                '}';
    }

    public String getCstid() {
        return cstid;
    }

    public void setCstid(String cstid) {
        this.cstid = cstid;
    }

    public String getSkyym() {
        return skyym;
    }

    public void setSkyym(String skyym) {
        this.skyym = skyym;
    }

    public String getSkg() {
        return skg;
    }

    public void setSkg(String skg) {
        this.skg = skg;
    }

    public String getBankcd() {
        return bankcd;
    }

    public void setBankcd(String bankcd) {
        this.bankcd = bankcd;
    }

    public String getBchcd() {
        return bchcd;
    }

    public void setBchcd(String bchcd) {
        this.bchcd = bchcd;
    }

    public String getYkn() {
        return ykn;
    }

    public void setYkn(String ykn) {
        this.ykn = ykn;
    }

    public String getActno() {
        return actno;
    }

    public void setActno(String actno) {
        this.actno = actno;
    }

    public String getActnae() {
        return actnae;
    }

    public void setActnae(String actnae) {
        this.actnae = actnae;
    }

    public String getSyoflg() {
        return syoflg;
    }

    public void setSyoflg(String syoflg) {
        this.syoflg = syoflg;
    }

    public String getBktskz() {
        return bktskz;
    }

    public void setBktskz(String bktskz) {
        this.bktskz = bktskz;
    }

    public String getInsertdte() {
        return insertdte;
    }

    public void setInsertdte(String insertdte) {
        this.insertdte = insertdte;
    }

    public String getInserttd() {
        return inserttd;
    }

    public void setInserttd(String inserttd) {
        this.inserttd = inserttd;
    }

    public String getUpdateid() {
        return updateid;
    }

    public void setUpdateid(String updateid) {
        this.updateid = updateid;
    }

    public String getUpdatedte() {
        return updatedte;
    }

    public void setUpdatedte(String updatedte) {
        this.updatedte = updatedte;
    }

    public String getDeleteflg() {
        return deleteflg;
    }

    public void setDeleteflg(String deleteflg) {
        this.deleteflg = deleteflg;
    }

    public String getDeteledte() {
        return deteledte;
    }

    public void setDeteledte(String deteledte) {
        this.deteledte = deteledte;
    }
}
