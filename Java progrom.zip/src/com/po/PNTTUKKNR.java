package com.po;

public class PNTTUKKNR {

    private String cstid;
    private String rkdte;
    private String sdkte;
    private String pntcou;
    private String insertdte;
    private String inserttd;
    private String updatedte;
    private String updateid;
    private String deleteflg;
    private String deletedte;

    public String getCstid() {
        return cstid;
    }

    public void setCstid(String cstid) {
        this.cstid = cstid;
    }

    public String getRkdte() {
        return rkdte;
    }

    public void setRkdte(String rkdte) {
        this.rkdte = rkdte;
    }

    public String getSdkte() {
        return sdkte;
    }

    public void setSdkte(String sdkte) {
        this.sdkte = sdkte;
    }

    public String getPntcou() {
        return pntcou;
    }

    public void setPntcou(String pntcou) {
        this.pntcou = pntcou;
    }

    public String getInsertdte() {
        return insertdte;
    }

    public void setInsertdte(String insertdte) {
        this.insertdte = insertdte;
    }

    public String getInserttd() {
        return inserttd;
    }

    public void setInserttd(String inserttd) {
        this.inserttd = inserttd;
    }

    public String getUpdatedte() {
        return updatedte;
    }

    public void setUpdatedte(String updatedte) {
        this.updatedte = updatedte;
    }

    public String getUpdateid() {
        return updateid;
    }

    public void setUpdateid(String updateid) {
        this.updateid = updateid;
    }

    public String getDeleteflg() {
        return deleteflg;
    }

    public void setDeleteflg(String deleteflg) {
        this.deleteflg = deleteflg;
    }

    public String getDeletedte() {
        return deletedte;
    }

    public void setDeletedte(String deletedte) {
        this.deletedte = deletedte;
    }
}
