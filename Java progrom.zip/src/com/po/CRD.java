package com.po;

public class CRD {
    private String crdcd;
    private String cstid;
    private String hnnkzk;
    private String ssflg;
    private String crdshucd;
    private String taxcd;
    private String crdykk;
    private String spgtorkbn;
    private String csgkbn;
    private String tspgtorkbn;
    private String tcsgkbn;
    private String tykk;
    private String crdsts;
    private String insertdte;
    private String inserttd;
    private String updatedte;
    private String updateid;
    private String deleteflg;
    private String deletedte;


    @Override
    public String toString() {
        return "CRD{" +
                "crdcd='" + crdcd + '\'' +
                ", cstid='" + cstid + '\'' +
                ", hnnkzk='" + hnnkzk + '\'' +
                ", ssflg='" + ssflg + '\'' +
                ", crdshucd='" + crdshucd + '\'' +
                ", taxcd='" + taxcd + '\'' +
                ", crdykk='" + crdykk + '\'' +
                ", spgtorkbn='" + spgtorkbn + '\'' +
                ", csgkbn='" + csgkbn + '\'' +
                ", tspgtorkbn='" + tspgtorkbn + '\'' +
                ", tcsgkbn='" + tcsgkbn + '\'' +
                ", tykk='" + tykk + '\'' +
                ", crdsts='" + crdsts + '\'' +
                ", insertdte='" + insertdte + '\'' +
                ", inserttd='" + inserttd + '\'' +
                ", updatedte='" + updatedte + '\'' +
                ", updateid='" + updateid + '\'' +
                ", deleteflg='" + deleteflg + '\'' +
                ", deletedte='" + deletedte + '\'' +
                '}';
    }

    public String getCrdcd() {
        return crdcd;
    }

    public void setCrdcd(String crdcd) {
        this.crdcd = crdcd;
    }

    public String getCstid() {
        return cstid;
    }

    public void setCstid(String cstid) {
        this.cstid = cstid;
    }

    public String getHnnkzk() {
        return hnnkzk;
    }

    public void setHnnkzk(String hnnkzk) {
        this.hnnkzk = hnnkzk;
    }

    public String getSsflg() {
        return ssflg;
    }

    public void setSsflg(String ssflg) {
        this.ssflg = ssflg;
    }

    public String getCrdshucd() {
        return crdshucd;
    }

    public void setCrdshucd(String crdshucd) {
        this.crdshucd = crdshucd;
    }

    public String getTaxcd() {
        return taxcd;
    }

    public void setTaxcd(String taxcd) {
        this.taxcd = taxcd;
    }

    public String getCrdykk() {
        return crdykk;
    }

    public void setCrdykk(String crdykk) {
        this.crdykk = crdykk;
    }

    public String getSpgtorkbn() {
        return spgtorkbn;
    }

    public void setSpgtorkbn(String spgtorkbn) {
        this.spgtorkbn = spgtorkbn;
    }

    public String getCsgkbn() {
        return csgkbn;
    }

    public void setCsgkbn(String csgkbn) {
        this.csgkbn = csgkbn;
    }

    public String getTspgtorkbn() {
        return tspgtorkbn;
    }

    public void setTspgtorkbn(String tspgtorkbn) {
        this.tspgtorkbn = tspgtorkbn;
    }

    public String getTcsgkbn() {
        return tcsgkbn;
    }

    public void setTcsgkbn(String tcsgkbn) {
        this.tcsgkbn = tcsgkbn;
    }

    public String getTykk() {
        return tykk;
    }

    public void setTykk(String tykk) {
        this.tykk = tykk;
    }

    public String getCrdsts() {
        return crdsts;
    }

    public void setCrdsts(String crdsts) {
        this.crdsts = crdsts;
    }

    public String getInsertdte() {
        return insertdte;
    }

    public void setInsertdte(String insertdte) {
        this.insertdte = insertdte;
    }

    public String getInserttd() {
        return inserttd;
    }

    public void setInserttd(String inserttd) {
        this.inserttd = inserttd;
    }

    public String getUpdatedte() {
        return updatedte;
    }

    public void setUpdatedte(String updatedte) {
        this.updatedte = updatedte;
    }

    public String getUpdateid() {
        return updateid;
    }

    public void setUpdateid(String updateid) {
        this.updateid = updateid;
    }

    public String getDeleteflg() {
        return deleteflg;
    }

    public void setDeleteflg(String deleteflg) {
        this.deleteflg = deleteflg;
    }

    public String getDeletedte() {
        return deletedte;
    }

    public void setDeletedte(String deletedte) {
        this.deletedte = deletedte;
    }
}
