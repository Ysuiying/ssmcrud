package com.po;

public class APP {

    private String appcd;
    private String cstid;
    private String syokbn;
    private String mail;
    private String ber;
    private String pho;
    private String ukttme;
    private String appsts;
    private String brdcd;
    private String crdshucd;
    private String kjnhjn;
    private String seikj;
    private String seikn;
    private String seien;
    private String meikj;
    private String meikn;
    private String meien;
    private String sex;
    private String jkysbt;
    private String tel;
    private String post;
    private String knc;
    private String jskj1;
    private String jskj2;
    private String jskn1;
    private String jskn2;
    private String spgtorkbn;
    private String spgkbn;
    private String csgkbn;
    private String torkbn;
    private String driverid;
    private String kkhcd;
    private String hgsumk;
    private String kzkmlflg;
    private String cammlflg;
    private String bankcd;
    private String bchcd;
    private String ykn;
    private String actcd;
    private String actnae;
    private String actkkndte;
    private String actkknid;
    private String actkknam;
    private String agtcd;
    private String hnnhhucd;
    private String hnnflg;
    private String hks1;
    private String hks2;
    private String hks3;
    private String hks4;
    private String hnnkkndte;
    private String hnnkknid;
    private String hnnkknnam;
    private String gyocd;
    private String kms;
    private String kmsdep;
    private String kmstel;
    private String kmsjs1;
    private String kmsjs2;
    private String nshym;
    private String nsg;
    private String kzkkbn;
    private String kzkflg;
    private String kzkseikj;
    private String kzkseikn;
    private String kzkseien;
    private String kzkmeikj;
    private String kzkmeikn;
    private String kzkmeien;
    private String kzksex;
    private String kzkgyocd;
    private String kzkkms;
    private String kzkkmsdep;
    private String kzkkmstel;
    private String kzkhhucd;
    private String kzkks1;
    private String kzkks2;
    private String kzkks3;
    private String kzkks4;
    private String kzkkkndte;
    private String kzkkknid;
    private String kzkkknnam;
    private String ysninf;
    private String skjsskflg;
    private String sskiritme;
    private String sskcd;
    private String sskjrytme;
    private String appcnctme;
    private String oldcrdcd;
    private String insertdte;
    private String insertid;
    private String updatedte;
    private String updateid;
    private String deleteflg;
    private String deletedte;

    @Override
    public String toString() {
        return "APP{" +
                "appcd='" + appcd + '\'' +
                ", cstid='" + cstid + '\'' +
                ", syokbn='" + syokbn + '\'' +
                ", mail='" + mail + '\'' +
                ", ber='" + ber + '\'' +
                ", pho='" + pho + '\'' +
                ", ukttme='" + ukttme + '\'' +
                ", appsts='" + appsts + '\'' +
                ", brdcd='" + brdcd + '\'' +
                ", crdshucd='" + crdshucd + '\'' +
                ", kjnhjn='" + kjnhjn + '\'' +
                ", seikj='" + seikj + '\'' +
                ", seikn='" + seikn + '\'' +
                ", seien='" + seien + '\'' +
                ", meikj='" + meikj + '\'' +
                ", meikn='" + meikn + '\'' +
                ", meien='" + meien + '\'' +
                ", sex='" + sex + '\'' +
                ", jkysbt='" + jkysbt + '\'' +
                ", tel='" + tel + '\'' +
                ", post='" + post + '\'' +
                ", knc='" + knc + '\'' +
                ", jskj1='" + jskj1 + '\'' +
                ", jskj2='" + jskj2 + '\'' +
                ", jskn1='" + jskn1 + '\'' +
                ", jskn2='" + jskn2 + '\'' +
                ", spgtorkbn='" + spgtorkbn + '\'' +
                ", spgkbn='" + spgkbn + '\'' +
                ", csgkbn='" + csgkbn + '\'' +
                ", torkbn='" + torkbn + '\'' +
                ", driverid='" + driverid + '\'' +
                ", kkhcd='" + kkhcd + '\'' +
                ", hgsumk='" + hgsumk + '\'' +
                ", kzkmlflg='" + kzkmlflg + '\'' +
                ", cammlflg='" + cammlflg + '\'' +
                ", bankcd='" + bankcd + '\'' +
                ", bchcd='" + bchcd + '\'' +
                ", ykn='" + ykn + '\'' +
                ", actcd='" + actcd + '\'' +
                ", actnae='" + actnae + '\'' +
                ", actkkndte='" + actkkndte + '\'' +
                ", actkknid='" + actkknid + '\'' +
                ", actkknam='" + actkknam + '\'' +
                ", agtcd='" + agtcd + '\'' +
                ", hnnhhucd='" + hnnhhucd + '\'' +
                ", hnnflg='" + hnnflg + '\'' +
                ", hks1='" + hks1 + '\'' +
                ", hks2='" + hks2 + '\'' +
                ", hks3='" + hks3 + '\'' +
                ", hks4='" + hks4 + '\'' +
                ", hnnkkndte='" + hnnkkndte + '\'' +
                ", hnnkknid='" + hnnkknid + '\'' +
                ", hnnkknnam='" + hnnkknnam + '\'' +
                ", gyocd='" + gyocd + '\'' +
                ", kms='" + kms + '\'' +
                ", kmsdep='" + kmsdep + '\'' +
                ", kmstel='" + kmstel + '\'' +
                ", kmsjs1='" + kmsjs1 + '\'' +
                ", kmsjs2='" + kmsjs2 + '\'' +
                ", nshym='" + nshym + '\'' +
                ", nsg='" + nsg + '\'' +
                ", kzkkbn='" + kzkkbn + '\'' +
                ", kzkflg='" + kzkflg + '\'' +
                ", kzkseikj='" + kzkseikj + '\'' +
                ", kzkseikn='" + kzkseikn + '\'' +
                ", kzkseien='" + kzkseien + '\'' +
                ", kzkmeikj='" + kzkmeikj + '\'' +
                ", kzkmeikn='" + kzkmeikn + '\'' +
                ", kzkmeien='" + kzkmeien + '\'' +
                ", kzksex='" + kzksex + '\'' +
                ", kzkgyocd='" + kzkgyocd + '\'' +
                ", kzkkms='" + kzkkms + '\'' +
                ", kzkkmsdep='" + kzkkmsdep + '\'' +
                ", kzkkmstel='" + kzkkmstel + '\'' +
                ", kzkhhucd='" + kzkhhucd + '\'' +
                ", kzkks1='" + kzkks1 + '\'' +
                ", kzkks2='" + kzkks2 + '\'' +
                ", kzkks3='" + kzkks3 + '\'' +
                ", kzkks4='" + kzkks4 + '\'' +
                ", kzkkkndte='" + kzkkkndte + '\'' +
                ", kzkkknid='" + kzkkknid + '\'' +
                ", kzkkknnam='" + kzkkknnam + '\'' +
                ", ysninf='" + ysninf + '\'' +
                ", skjsskflg='" + skjsskflg + '\'' +
                ", sskiritme='" + sskiritme + '\'' +
                ", sskcd='" + sskcd + '\'' +
                ", sskjrytme='" + sskjrytme + '\'' +
                ", appcnctme='" + appcnctme + '\'' +
                ", oldcrdcd='" + oldcrdcd + '\'' +
                ", insertdte='" + insertdte + '\'' +
                ", insertid='" + insertid + '\'' +
                ", updatedte='" + updatedte + '\'' +
                ", updateid='" + updateid + '\'' +
                ", deleteflg='" + deleteflg + '\'' +
                ", deletedte='" + deletedte + '\'' +
                '}';
    }

    public String getAppcd() {
        return appcd;
    }

    public void setAppcd(String appcd) {
        this.appcd = appcd;
    }

    public String getCstid() {
        return cstid;
    }

    public void setCstid(String cstid) {
        this.cstid = cstid;
    }

    public String getSyokbn() {
        return syokbn;
    }

    public void setSyokbn(String syokbn) {
        this.syokbn = syokbn;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public String getBer() {
        return ber;
    }

    public void setBer(String ber) {
        this.ber = ber;
    }

    public String getPho() {
        return pho;
    }

    public void setPho(String pho) {
        this.pho = pho;
    }

    public String getUkttme() {
        return ukttme;
    }

    public void setUkttme(String ukttme) {
        this.ukttme = ukttme;
    }

    public String getAppsts() {
        return appsts;
    }

    public void setAppsts(String appsts) {
        this.appsts = appsts;
    }

    public String getBrdcd() {
        return brdcd;
    }

    public void setBrdcd(String brdcd) {
        this.brdcd = brdcd;
    }

    public String getCrdshucd() {
        return crdshucd;
    }

    public void setCrdshucd(String crdshucd) {
        this.crdshucd = crdshucd;
    }

    public String getKjnhjn() {
        return kjnhjn;
    }

    public void setKjnhjn(String kjnhjn) {
        this.kjnhjn = kjnhjn;
    }

    public String getSeikj() {
        return seikj;
    }

    public void setSeikj(String seikj) {
        this.seikj = seikj;
    }

    public String getSeikn() {
        return seikn;
    }

    public void setSeikn(String seikn) {
        this.seikn = seikn;
    }

    public String getSeien() {
        return seien;
    }

    public void setSeien(String seien) {
        this.seien = seien;
    }

    public String getMeikj() {
        return meikj;
    }

    public void setMeikj(String meikj) {
        this.meikj = meikj;
    }

    public String getMeikn() {
        return meikn;
    }

    public void setMeikn(String meikn) {
        this.meikn = meikn;
    }

    public String getMeien() {
        return meien;
    }

    public void setMeien(String meien) {
        this.meien = meien;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getJkysbt() {
        return jkysbt;
    }

    public void setJkysbt(String jkysbt) {
        this.jkysbt = jkysbt;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getPost() {
        return post;
    }

    public void setPost(String post) {
        this.post = post;
    }

    public String getKnc() {
        return knc;
    }

    public void setKnc(String knc) {
        this.knc = knc;
    }

    public String getJskj1() {
        return jskj1;
    }

    public void setJskj1(String jskj1) {
        this.jskj1 = jskj1;
    }

    public String getJskj2() {
        return jskj2;
    }

    public void setJskj2(String jskj2) {
        this.jskj2 = jskj2;
    }

    public String getJskn1() {
        return jskn1;
    }

    public void setJskn1(String jskn1) {
        this.jskn1 = jskn1;
    }

    public String getJskn2() {
        return jskn2;
    }

    public void setJskn2(String jskn2) {
        this.jskn2 = jskn2;
    }

    public String getSpgtorkbn() {
        return spgtorkbn;
    }

    public void setSpgtorkbn(String spgtorkbn) {
        this.spgtorkbn = spgtorkbn;
    }

    public String getSpgkbn() {
        return spgkbn;
    }

    public void setSpgkbn(String spgkbn) {
        this.spgkbn = spgkbn;
    }

    public String getCsgkbn() {
        return csgkbn;
    }

    public void setCsgkbn(String csgkbn) {
        this.csgkbn = csgkbn;
    }

    public String getTorkbn() {
        return torkbn;
    }

    public void setTorkbn(String torkbn) {
        this.torkbn = torkbn;
    }

    public String getDriverid() {
        return driverid;
    }

    public void setDriverid(String driverid) {
        this.driverid = driverid;
    }

    public String getKkhcd() {
        return kkhcd;
    }

    public void setKkhcd(String kkhcd) {
        this.kkhcd = kkhcd;
    }

    public String getHgsumk() {
        return hgsumk;
    }

    public void setHgsumk(String hgsumk) {
        this.hgsumk = hgsumk;
    }

    public String getKzkmlflg() {
        return kzkmlflg;
    }

    public void setKzkmlflg(String kzkmlflg) {
        this.kzkmlflg = kzkmlflg;
    }

    public String getCammlflg() {
        return cammlflg;
    }

    public void setCammlflg(String cammlflg) {
        this.cammlflg = cammlflg;
    }

    public String getBankcd() {
        return bankcd;
    }

    public void setBankcd(String bankcd) {
        this.bankcd = bankcd;
    }

    public String getBchcd() {
        return bchcd;
    }

    public void setBchcd(String bchcd) {
        this.bchcd = bchcd;
    }

    public String getYkn() {
        return ykn;
    }

    public void setYkn(String ykn) {
        this.ykn = ykn;
    }

    public String getActcd() {
        return actcd;
    }

    public void setActcd(String actcd) {
        this.actcd = actcd;
    }

    public String getActnae() {
        return actnae;
    }

    public void setActnae(String actnae) {
        this.actnae = actnae;
    }

    public String getActkkndte() {
        return actkkndte;
    }

    public void setActkkndte(String actkkndte) {
        this.actkkndte = actkkndte;
    }

    public String getActkknid() {
        return actkknid;
    }

    public void setActkknid(String actkknid) {
        this.actkknid = actkknid;
    }

    public String getActkknam() {
        return actkknam;
    }

    public void setActkknam(String actkknam) {
        this.actkknam = actkknam;
    }

    public String getAgtcd() {
        return agtcd;
    }

    public void setAgtcd(String agtcd) {
        this.agtcd = agtcd;
    }

    public String getHnnhhucd() {
        return hnnhhucd;
    }

    public void setHnnhhucd(String hnnhhucd) {
        this.hnnhhucd = hnnhhucd;
    }

    public String getHnnflg() {
        return hnnflg;
    }

    public void setHnnflg(String hnnflg) {
        this.hnnflg = hnnflg;
    }

    public String getHks1() {
        return hks1;
    }

    public void setHks1(String hks1) {
        this.hks1 = hks1;
    }

    public String getHks2() {
        return hks2;
    }

    public void setHks2(String hks2) {
        this.hks2 = hks2;
    }

    public String getHks3() {
        return hks3;
    }

    public void setHks3(String hks3) {
        this.hks3 = hks3;
    }

    public String getHks4() {
        return hks4;
    }

    public void setHks4(String hks4) {
        this.hks4 = hks4;
    }

    public String getHnnkkndte() {
        return hnnkkndte;
    }

    public void setHnnkkndte(String hnnkkndte) {
        this.hnnkkndte = hnnkkndte;
    }

    public String getHnnkknid() {
        return hnnkknid;
    }

    public void setHnnkknid(String hnnkknid) {
        this.hnnkknid = hnnkknid;
    }

    public String getHnnkknnam() {
        return hnnkknnam;
    }

    public void setHnnkknnam(String hnnkknnam) {
        this.hnnkknnam = hnnkknnam;
    }

    public String getGyocd() {
        return gyocd;
    }

    public void setGyocd(String gyocd) {
        this.gyocd = gyocd;
    }

    public String getKms() {
        return kms;
    }

    public void setKms(String kms) {
        this.kms = kms;
    }

    public String getKmsdep() {
        return kmsdep;
    }

    public void setKmsdep(String kmsdep) {
        this.kmsdep = kmsdep;
    }

    public String getKmstel() {
        return kmstel;
    }

    public void setKmstel(String kmstel) {
        this.kmstel = kmstel;
    }

    public String getKmsjs1() {
        return kmsjs1;
    }

    public void setKmsjs1(String kmsjs1) {
        this.kmsjs1 = kmsjs1;
    }

    public String getKmsjs2() {
        return kmsjs2;
    }

    public void setKmsjs2(String kmsjs2) {
        this.kmsjs2 = kmsjs2;
    }

    public String getNshym() {
        return nshym;
    }

    public void setNshym(String nshym) {
        this.nshym = nshym;
    }

    public String getNsg() {
        return nsg;
    }

    public void setNsg(String nsg) {
        this.nsg = nsg;
    }

    public String getKzkkbn() {
        return kzkkbn;
    }

    public void setKzkkbn(String kzkkbn) {
        this.kzkkbn = kzkkbn;
    }

    public String getKzkflg() {
        return kzkflg;
    }

    public void setKzkflg(String kzkflg) {
        this.kzkflg = kzkflg;
    }

    public String getKzkseikj() {
        return kzkseikj;
    }

    public void setKzkseikj(String kzkseikj) {
        this.kzkseikj = kzkseikj;
    }

    public String getKzkseikn() {
        return kzkseikn;
    }

    public void setKzkseikn(String kzkseikn) {
        this.kzkseikn = kzkseikn;
    }

    public String getKzkseien() {
        return kzkseien;
    }

    public void setKzkseien(String kzkseien) {
        this.kzkseien = kzkseien;
    }

    public String getKzkmeikj() {
        return kzkmeikj;
    }

    public void setKzkmeikj(String kzkmeikj) {
        this.kzkmeikj = kzkmeikj;
    }

    public String getKzkmeikn() {
        return kzkmeikn;
    }

    public void setKzkmeikn(String kzkmeikn) {
        this.kzkmeikn = kzkmeikn;
    }

    public String getKzkmeien() {
        return kzkmeien;
    }

    public void setKzkmeien(String kzkmeien) {
        this.kzkmeien = kzkmeien;
    }

    public String getKzksex() {
        return kzksex;
    }

    public void setKzksex(String kzksex) {
        this.kzksex = kzksex;
    }

    public String getKzkgyocd() {
        return kzkgyocd;
    }

    public void setKzkgyocd(String kzkgyocd) {
        this.kzkgyocd = kzkgyocd;
    }

    public String getKzkkms() {
        return kzkkms;
    }

    public void setKzkkms(String kzkkms) {
        this.kzkkms = kzkkms;
    }

    public String getKzkkmsdep() {
        return kzkkmsdep;
    }

    public void setKzkkmsdep(String kzkkmsdep) {
        this.kzkkmsdep = kzkkmsdep;
    }

    public String getKzkkmstel() {
        return kzkkmstel;
    }

    public void setKzkkmstel(String kzkkmstel) {
        this.kzkkmstel = kzkkmstel;
    }

    public String getKzkhhucd() {
        return kzkhhucd;
    }

    public void setKzkhhucd(String kzkhhucd) {
        this.kzkhhucd = kzkhhucd;
    }

    public String getKzkks1() {
        return kzkks1;
    }

    public void setKzkks1(String kzkks1) {
        this.kzkks1 = kzkks1;
    }

    public String getKzkks2() {
        return kzkks2;
    }

    public void setKzkks2(String kzkks2) {
        this.kzkks2 = kzkks2;
    }

    public String getKzkks3() {
        return kzkks3;
    }

    public void setKzkks3(String kzkks3) {
        this.kzkks3 = kzkks3;
    }

    public String getKzkks4() {
        return kzkks4;
    }

    public void setKzkks4(String kzkks4) {
        this.kzkks4 = kzkks4;
    }

    public String getKzkkkndte() {
        return kzkkkndte;
    }

    public void setKzkkkndte(String kzkkkndte) {
        this.kzkkkndte = kzkkkndte;
    }

    public String getKzkkknid() {
        return kzkkknid;
    }

    public void setKzkkknid(String kzkkknid) {
        this.kzkkknid = kzkkknid;
    }

    public String getKzkkknnam() {
        return kzkkknnam;
    }

    public void setKzkkknnam(String kzkkknnam) {
        this.kzkkknnam = kzkkknnam;
    }

    public String getYsninf() {
        return ysninf;
    }

    public void setYsninf(String ysninf) {
        this.ysninf = ysninf;
    }

    public String getSkjsskflg() {
        return skjsskflg;
    }

    public void setSkjsskflg(String skjsskflg) {
        this.skjsskflg = skjsskflg;
    }

    public String getSskiritme() {
        return sskiritme;
    }

    public void setSskiritme(String sskiritme) {
        this.sskiritme = sskiritme;
    }

    public String getSskcd() {
        return sskcd;
    }

    public void setSskcd(String sskcd) {
        this.sskcd = sskcd;
    }

    public String getSskjrytme() {
        return sskjrytme;
    }

    public void setSskjrytme(String sskjrytme) {
        this.sskjrytme = sskjrytme;
    }

    public String getAppcnctme() {
        return appcnctme;
    }

    public void setAppcnctme(String appcnctme) {
        this.appcnctme = appcnctme;
    }

    public String getOldcrdcd() {
        return oldcrdcd;
    }

    public void setOldcrdcd(String oldcrdcd) {
        this.oldcrdcd = oldcrdcd;
    }

    public String getInsertdte() {
        return insertdte;
    }

    public void setInsertdte(String insertdte) {
        this.insertdte = insertdte;
    }

    public String getInsertid() {
        return insertid;
    }

    public void setInsertid(String insertid) {
        this.insertid = insertid;
    }

    public String getUpdatedte() {
        return updatedte;
    }

    public void setUpdatedte(String updatedte) {
        this.updatedte = updatedte;
    }

    public String getUpdateid() {
        return updateid;
    }

    public void setUpdateid(String updateid) {
        this.updateid = updateid;
    }

    public String getDeleteflg() {
        return deleteflg;
    }

    public void setDeleteflg(String deleteflg) {
        this.deleteflg = deleteflg;
    }

    public String getDeletedte() {
        return deletedte;
    }

    public void setDeletedte(String deletedte) {
        this.deletedte = deletedte;
    }
}
