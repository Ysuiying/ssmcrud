package com.po;

public class CST {
    private String cstid;
    private String hnnkzk;
    private String sei;
    private String seikana;
    private String seien;
    private String mei;
    private String meikana;
    private String meien;
    private String btn;
    private String sex;
    private String kjnhjn;
    private String tel;
    private String phone;
    private String jkysbt;
    private String post;
    private String knc;
    private String jskj1;
    private String jskj2;
    private String jskn1;
    private String jskn2;
    private String gyocd;
    private String kms;
    private String kmsdep;
    private String kmstel;
    private String kmsjs1;
    private String kmsjs2;
    private String nyusyaym;
    private String driverid;
    private String kkhcd;
    private String bankcd;
    private String bchcd;
    private String ykn;
    private String actcd;
    private String actnae;
    private String kzkmlflg;
    private String cammlflg;
    private String etcflg;
    private String insertdte;
    private String insertid;
    private String updatedte;
    private String updateid;
    private String deleteflg;
    private String deletedte;

    public String getCstid() {
        return cstid;
    }

    public void setCstid(String cstid) {
        this.cstid = cstid;
    }

    public String getHnnkzk() {
        return hnnkzk;
    }

    public void setHnnkzk(String hnnkzk) {
        this.hnnkzk = hnnkzk;
    }

    public String getSei() {
        return sei;
    }

    public void setSei(String sei) {
        this.sei = sei;
    }

    public String getSeikana() {
        return seikana;
    }

    public void setSeikana(String seikana) {
        this.seikana = seikana;
    }

    public String getSeien() {
        return seien;
    }

    public void setSeien(String seien) {
        this.seien = seien;
    }

    public String getMei() {
        return mei;
    }

    public void setMei(String mei) {
        this.mei = mei;
    }

    public String getMeikana() {
        return meikana;
    }

    public void setMeikana(String meikana) {
        this.meikana = meikana;
    }

    public String getMeien() {
        return meien;
    }

    public void setMeien(String meien) {
        this.meien = meien;
    }

    public String getBtn() {
        return btn;
    }

    public void setBtn(String btn) {
        this.btn = btn;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getKjnhjn() {
        return kjnhjn;
    }

    public void setKjnhjn(String kjnhjn) {
        this.kjnhjn = kjnhjn;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getJkysbt() {
        return jkysbt;
    }

    public void setJkysbt(String jkysbt) {
        this.jkysbt = jkysbt;
    }

    public String getPost() {
        return post;
    }

    public void setPost(String post) {
        this.post = post;
    }

    public String getKnc() {
        return knc;
    }

    public void setKnc(String knc) {
        this.knc = knc;
    }

    public String getJskj1() {
        return jskj1;
    }

    public void setJskj1(String jskj1) {
        this.jskj1 = jskj1;
    }

    public String getJskj2() {
        return jskj2;
    }

    public void setJskj2(String jskj2) {
        this.jskj2 = jskj2;
    }

    public String getJskn1() {
        return jskn1;
    }

    public void setJskn1(String jskn1) {
        this.jskn1 = jskn1;
    }

    public String getJskn2() {
        return jskn2;
    }

    public void setJskn2(String jskn2) {
        this.jskn2 = jskn2;
    }

    public String getGyocd() {
        return gyocd;
    }

    public void setGyocd(String gyocd) {
        this.gyocd = gyocd;
    }

    public String getKms() {
        return kms;
    }

    public void setKms(String kms) {
        this.kms = kms;
    }

    public String getKmsdep() {
        return kmsdep;
    }

    public void setKmsdep(String kmsdep) {
        this.kmsdep = kmsdep;
    }

    public String getKmstel() {
        return kmstel;
    }

    public void setKmstel(String kmstel) {
        this.kmstel = kmstel;
    }

    public String getKmsjs1() {
        return kmsjs1;
    }

    public void setKmsjs1(String kmsjs1) {
        this.kmsjs1 = kmsjs1;
    }

    public String getKmsjs2() {
        return kmsjs2;
    }

    public void setKmsjs2(String kmsjs2) {
        this.kmsjs2 = kmsjs2;
    }

    public String getNyusyaym() {
        return nyusyaym;
    }

    public void setNyusyaym(String nyusyaym) {
        this.nyusyaym = nyusyaym;
    }

    public String getDriverid() {
        return driverid;
    }

    public void setDriverid(String driverid) {
        this.driverid = driverid;
    }

    public String getKkhcd() {
        return kkhcd;
    }

    public void setKkhcd(String kkhcd) {
        this.kkhcd = kkhcd;
    }

    public String getBankcd() {
        return bankcd;
    }

    public void setBankcd(String bankcd) {
        this.bankcd = bankcd;
    }

    public String getBchcd() {
        return bchcd;
    }

    public void setBchcd(String bchcd) {
        this.bchcd = bchcd;
    }

    public String getYkn() {
        return ykn;
    }

    public void setYkn(String ykn) {
        this.ykn = ykn;
    }

    public String getActcd() {
        return actcd;
    }

    public void setActcd(String actcd) {
        this.actcd = actcd;
    }

    public String getActnae() {
        return actnae;
    }

    public void setActnae(String actnae) {
        this.actnae = actnae;
    }

    public String getKzkmlflg() {
        return kzkmlflg;
    }

    public void setKzkmlflg(String kzkmlflg) {
        this.kzkmlflg = kzkmlflg;
    }

    public String getCammlflg() {
        return cammlflg;
    }

    public void setCammlflg(String cammlflg) {
        this.cammlflg = cammlflg;
    }

    public String getEtcflg() {
        return etcflg;
    }

    public void setEtcflg(String etcflg) {
        this.etcflg = etcflg;
    }

    public String getInsertdte() {
        return insertdte;
    }

    public void setInsertdte(String insertdte) {
        this.insertdte = insertdte;
    }

    public String getInsertid() {
        return insertid;
    }

    public void setInsertid(String insertid) {
        this.insertid = insertid;
    }

    public String getUpdatedte() {
        return updatedte;
    }

    public void setUpdatedte(String updatedte) {
        this.updatedte = updatedte;
    }

    public String getUpdateid() {
        return updateid;
    }

    public void setUpdateid(String updateid) {
        this.updateid = updateid;
    }

    public String getDeleteflg() {
        return deleteflg;
    }

    public void setDeleteflg(String deleteflg) {
        this.deleteflg = deleteflg;
    }

    public String getDeletedte() {
        return deletedte;
    }

    public void setDeletedte(String deletedte) {
        this.deletedte = deletedte;
    }

}
