package com.po;

public class CAMPINF {

    private String campid;
    private String campn;
    private String ykkks;
    private String ykkke;
    private String ktkytiym;
    private String pntcou;
    private String insertdte;
    private String inserttd;
    private String updatedte;
    private String updateid;
    private String deleteflg;
    private String deletedte;

    public String getCampid() {
        return campid;
    }

    public void setCampid(String campid) {
        this.campid = campid;
    }

    public String getCampn() {
        return campn;
    }

    public void setCampn(String campn) {
        this.campn = campn;
    }

    public String getYkkks() {
        return ykkks;
    }

    public void setYkkks(String ykkks) {
        this.ykkks = ykkks;
    }

    public String getYkkke() {
        return ykkke;
    }

    public void setYkkke(String ykkke) {
        this.ykkke = ykkke;
    }

    public String getKtkytiym() {
        return ktkytiym;
    }

    public void setKtkytiym(String ktkytiym) {
        this.ktkytiym = ktkytiym;
    }

    public String getPntcou() {
        return pntcou;
    }

    public void setPntcou(String pntcou) {
        this.pntcou = pntcou;
    }

    public String getInsertdte() {
        return insertdte;
    }

    public void setInsertdte(String insertdte) {
        this.insertdte = insertdte;
    }

    public String getInserttd() {
        return inserttd;
    }

    public void setInserttd(String inserttd) {
        this.inserttd = inserttd;
    }

    public String getUpdatedte() {
        return updatedte;
    }

    public void setUpdatedte(String updatedte) {
        this.updatedte = updatedte;
    }

    public String getUpdateid() {
        return updateid;
    }

    public void setUpdateid(String updateid) {
        this.updateid = updateid;
    }

    public String getDeleteflg() {
        return deleteflg;
    }

    public void setDeleteflg(String deleteflg) {
        this.deleteflg = deleteflg;
    }

    public String getDeletedte() {
        return deletedte;
    }

    public void setDeletedte(String deletedte) {
        this.deletedte = deletedte;
    }
}
