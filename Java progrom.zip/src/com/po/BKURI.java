package com.po;

public class BKURI {
    private String seq;
    private String kino;
    private String cstid;
    private String hnnkzk;
    private String bkuag;
    private String tesuryo;
    private String tsk;
    private String skyym;
    private String tskflg;
    private String insertdte;
    private String inserttd;
    private String updateid;
    private String updatedte;
    private String deleteflg;
    private String deteledte;

    @Override
    public String toString() {
        return "BKURI{" +
                "seq='" + seq + '\'' +
                ", kino='" + kino + '\'' +
                ", cstid='" + cstid + '\'' +
                ", hnnkzk='" + hnnkzk + '\'' +
                ", bkuag='" + bkuag + '\'' +
                ", tesuryo='" + tesuryo + '\'' +
                ", tsk='" + tsk + '\'' +
                ", skyym='" + skyym + '\'' +
                ", tskflg='" + tskflg + '\'' +
                ", insertdte='" + insertdte + '\'' +
                ", inserttd='" + inserttd + '\'' +
                ", updateid='" + updateid + '\'' +
                ", updatedte='" + updatedte + '\'' +
                ", deleteflg='" + deleteflg + '\'' +
                ", deteledte='" + deteledte + '\'' +
                '}';
    }

    public String getSeq() {
        return seq;
    }

    public void setSeq(String seq) {
        this.seq = seq;
    }

    public String getKino() {
        return kino;
    }

    public void setKino(String kino) {
        this.kino = kino;
    }

    public String getCstid() {
        return cstid;
    }

    public void setCstid(String cstid) {
        this.cstid = cstid;
    }

    public String getHnnkzk() {
        return hnnkzk;
    }

    public void setHnnkzk(String hnnkzk) {
        this.hnnkzk = hnnkzk;
    }

    public String getBkuag() {
        return bkuag;
    }

    public void setBkuag(String bkuag) {
        this.bkuag = bkuag;
    }

    public String getTesuryo() {
        return tesuryo;
    }

    public void setTesuryo(String tesuryo) {
        this.tesuryo = tesuryo;
    }

    public String getTsk() {
        return tsk;
    }

    public void setTsk(String tsk) {
        this.tsk = tsk;
    }

    public String getSkyym() {
        return skyym;
    }

    public void setSkyym(String skyym) {
        this.skyym = skyym;
    }

    public String getTskflg() {
        return tskflg;
    }

    public void setTskflg(String tskflg) {
        this.tskflg = tskflg;
    }

    public String getInsertdte() {
        return insertdte;
    }

    public void setInsertdte(String insertdte) {
        this.insertdte = insertdte;
    }

    public String getInserttd() {
        return inserttd;
    }

    public void setInserttd(String inserttd) {
        this.inserttd = inserttd;
    }

    public String getUpdateid() {
        return updateid;
    }

    public void setUpdateid(String updateid) {
        this.updateid = updateid;
    }

    public String getUpdatedte() {
        return updatedte;
    }

    public void setUpdatedte(String updatedte) {
        this.updatedte = updatedte;
    }

    public String getDeleteflg() {
        return deleteflg;
    }

    public void setDeleteflg(String deleteflg) {
        this.deleteflg = deleteflg;
    }

    public String getDeteledte() {
        return deteledte;
    }

    public void setDeteledte(String deteledte) {
        this.deteledte = deteledte;
    }
}
