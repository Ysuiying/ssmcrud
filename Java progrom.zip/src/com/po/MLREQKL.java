package com.po;

public class MLREQKL {
    private String seq;
    private String mlid;
    private String cstid;
    private String mlfrom;
    private String mlto;
    private String reqsts;
    private String reqdte;
    private String mlbody;
    private String insertdte;
    private String inserttd;
    private String updatedte;
    private String updateid;
    private String deleteflg;
    private String deletedte;

    public String getSeq() {
        return seq;
    }

    public void setSeq(String seq) {
        this.seq = seq;
    }

    public String getMlid() {
        return mlid;
    }

    public void setMlid(String mlid) {
        this.mlid = mlid;
    }

    public String getCstid() {
        return cstid;
    }

    public void setCstid(String cstid) {
        this.cstid = cstid;
    }

    public String getMlfrom() {
        return mlfrom;
    }

    public void setMlfrom(String mlfrom) {
        this.mlfrom = mlfrom;
    }

    public String getMlto() {
        return mlto;
    }

    public void setMlto(String mlto) {
        this.mlto = mlto;
    }

    public String getReqsts() {
        return reqsts;
    }

    public void setReqsts(String reqsts) {
        this.reqsts = reqsts;
    }

    public String getReqdte() {
        return reqdte;
    }

    public void setReqdte(String reqdte) {
        this.reqdte = reqdte;
    }

    public String getMlbody() {
        return mlbody;
    }

    public void setMlbody(String mlbody) {
        this.mlbody = mlbody;
    }

    public String getInsertdte() {
        return insertdte;
    }

    public void setInsertdte(String insertdte) {
        this.insertdte = insertdte;
    }

    public String getInserttd() {
        return inserttd;
    }

    public void setInserttd(String inserttd) {
        this.inserttd = inserttd;
    }

    public String getUpdatedte() {
        return updatedte;
    }

    public void setUpdatedte(String updatedte) {
        this.updatedte = updatedte;
    }

    public String getUpdateid() {
        return updateid;
    }

    public void setUpdateid(String updateid) {
        this.updateid = updateid;
    }

    public String getDeleteflg() {
        return deleteflg;
    }

    public void setDeleteflg(String deleteflg) {
        this.deleteflg = deleteflg;
    }

    public String getDeletedte() {
        return deletedte;
    }

    public void setDeletedte(String deletedte) {
        this.deletedte = deletedte;
    }
}